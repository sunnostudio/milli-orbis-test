# MilliOrbis 虹深°ぬふ Cursors for Chromebook

![preview](preview.png)

**虹深°ぬふ（Nuhu）** のオリジナルカーソル 15種を Chromebook の Chrome ブラウザで使えます。

> **Chromebook のシステム全体**ではカスタム画像のカーソルは OS制限で直接変更できません。**Chromeブラウザ内**でのみ有効です（Chromebookの主用途はブラウザのため実用上は十分です）。

## インストール（Chromebook）— 拡張で適用

1. Chromeウェブストアで [Custom Cursor for Chrome](https://chrome.google.com/webstore/detail/custom-cursor-for-chrome/ogdlpmhglpejoiomcodnpjnfgcpmgale) を `Add to Chrome` → `Add extension`
2. 拡張の管理画面（`chrome://extensions` → `Details` → `Extension options` または拡張アイコン → `Manage`）で `Upload cursor` から本 `MilliOrbis-Nuhu-chromebook.zip` を解凍した `png/` 内の `png` を登録
   - 対応: `arrow=Normal`, `hand=Pointer`, `beam=Text`, `wait=Busy` 等（詳細は `hotspot.json` を参照）
3. 必要なら `Chromebook Settings → Accessibility → Cursor` でサイズ調整

## サイト内での利用

Chromebook でも `cursors.html` の `サイトで試す` やヘッダーの `カーソル` から即時切り替えできます。

## ファイル

- `png/*.png` — 15種の透過PNG（32px）
- `hotspot.json` — 各pngのホットスポット座標
- `preview.png` — プレビュー

## ライセンス

- 個人で楽しむ範囲での利用のみ可。**再配布・転載・販売・商用利用はすべて禁止**です。
- 詳細は同梱の `LICENSE` を参照してください。
- Cursor design: すんすん (@SunSunmachi)
